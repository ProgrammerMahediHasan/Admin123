<?php
class LeaveConfigurationController extends Controller{
	public function __construct(){
	}
	public function index(){
		view("leave_configuration");
	}
	public function create(){
		view("leave_configuration");
	}
public function save($data,$file){
	if(isset($data["create"])){
	$errors=[];
/*
	if(!preg_match("/^[\s\S]+$/",$_POST["txtLeaveType"])){
		$errors["leave_type"]="Invalid leave_type";
	}
	if(!preg_match("/^[\s\S]+$/",$data["total_days"])){
		$errors["total_days"]="Invalid total_days";
	}
	if(!preg_match("/^[\s\S]+$/",$data["carry_forward"])){
		$errors["carry_forward"]="Invalid carry_forward";
	}
	if(!preg_match("/^[\s\S]+$/",$data["description"])){
		$errors["description"]="Invalid description";
	}
	if(!preg_match("/^[\s\S]+$/",$data["status"])){
		$errors["status"]="Invalid status";
	}

*/
		if(count($errors)==0){
			$leaveconfiguration=new LeaveConfiguration();
		$leaveconfiguration->leave_type=$data["leave_type"];
		$leaveconfiguration->total_days=$data["total_days"];
		$leaveconfiguration->carry_forward=$data["carry_forward"];
		$leaveconfiguration->description=$data["description"];
		$leaveconfiguration->status=$data["status"];

			$leaveconfiguration->save();
		redirect();
		}else{
			 print_r($errors);
		}
	}
}
public function edit($id){
		view("leave_configuration",LeaveConfiguration::find($id));
}
public function update($data,$file){
	if(isset($data["update"])){
	$errors=[];
/*
	if(!preg_match("/^[\s\S]+$/",$_POST["txtLeaveType"])){
		$errors["leave_type"]="Invalid leave_type";
	}
	if(!preg_match("/^[\s\S]+$/",$data["total_days"])){
		$errors["total_days"]="Invalid total_days";
	}
	if(!preg_match("/^[\s\S]+$/",$data["carry_forward"])){
		$errors["carry_forward"]="Invalid carry_forward";
	}
	if(!preg_match("/^[\s\S]+$/",$data["description"])){
		$errors["description"]="Invalid description";
	}
	if(!preg_match("/^[\s\S]+$/",$data["status"])){
		$errors["status"]="Invalid status";
	}

*/
		if(count($errors)==0){
			$leaveconfiguration=new LeaveConfiguration();
			$leaveconfiguration->id=$data["id"];
		$leaveconfiguration->leave_type=$data["leave_type"];
		$leaveconfiguration->total_days=$data["total_days"];
		$leaveconfiguration->carry_forward=$data["carry_forward"];
		$leaveconfiguration->description=$data["description"];
		$leaveconfiguration->status=$data["status"];

		$leaveconfiguration->update();
		redirect();
		}else{
			 print_r($errors);
		}
	}
}
	public function confirm($id){
		view("leave_configuration");
	}
	public function delete($id){
		LeaveConfiguration::delete($id);
		redirect();
	}
	public function show($id){
		view("leave_configuration",LeaveConfiguration::find($id));
	}
}
?>
