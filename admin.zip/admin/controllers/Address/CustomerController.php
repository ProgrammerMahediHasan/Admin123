<?php

class CustomerController extends Controller {
 	public function index(){
		view("Test");
	}
}



?>