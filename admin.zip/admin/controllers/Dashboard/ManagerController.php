<?php 
class ManagerController{
    function index(){
        view("dashboard");
    }
}