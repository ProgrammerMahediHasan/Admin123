<?php
echo Page::title(["title" => "Edit Leave Configuration"]);
echo Page::body_open();

// Back Button
echo Html::link([
    "class" => "btn btn-secondary mb-3",
    "route" => "leaveconfiguration",
    "text" => "← Back to Manage Leave Configuration"
]);

echo Page::context_open();
?>

<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');

body { font-family: 'Poppins', sans-serif; background: linear-gradient(120deg, #e8f0ff 0%, #f5f7fa 100%); padding: 40px; }
.form-card { max-width: 700px; margin: 0 auto; background: #fff; border-radius: 18px; box-shadow: 0 8px 25px rgba(0,0,0,0.08); overflow: hidden; border: 1px solid #e6e9ef; }
.form-header { background: linear-gradient(135deg, #2563eb, #1d4ed8); color: #fff; padding: 25px 30px; text-align: center; position: relative; }
.form-header::after { content: ""; position: absolute; width: 80px; height: 4px; background: #60a5fa; bottom: 0; left: 50%; transform: translateX(-50%); border-radius: 2px; }
.form-header h2 { margin: 0; font-size: 24px; font-weight: 600; }
.form-header p { margin-top: 5px; font-size: 14px; opacity: 0.9; }

.form-body { padding: 30px 35px; }
.form-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px 30px; }
.form-group { position: relative; margin-top: 15px; }
.form-group input, .form-group select, .form-group textarea { width: 100%; padding: 14px 14px 14px 12px; border: 1px solid #d1d5db; border-radius: 10px; background: #f9fafb; font-size: 14px; outline: none; transition: all 0.3s ease; }
.form-group label { position: absolute; top: 14px; left: 14px; color: #777; font-size: 14px; font-weight: 500; transition: all 0.3s ease; pointer-events: none; }
.form-group input:focus + label,
.form-group input:not(:placeholder-shown) + label,
.form-group select:focus + label,
.form-group select:not([value=""]) + label,
.form-group textarea:focus + label,
.form-group textarea:not(:placeholder-shown) + label
{ top: -10px; left: 10px; background: #fff; color: #2563eb; font-size: 12px; padding: 0 5px; }

.form-group input:focus, .form-group select:focus, .form-group textarea:focus { border-color: #2563eb; box-shadow: 0 0 8px rgba(37,99,235,0.25); background-color: #fff; }

.btn-submit { grid-column: 1 / -1; justify-self: center; padding: 14px 36px; background: linear-gradient(135deg, #2563eb, #1d4ed8); color: #fff; border: none; border-radius: 10px; font-weight: 600; font-size: 15px; cursor: pointer; transition: 0.3s ease; box-shadow: 0 5px 15px rgba(37,99,235,0.25); }
.btn-submit:hover { background: linear-gradient(135deg, #1e40af, #1d4ed8); transform: translateY(-2px); box-shadow: 0 8px 20px rgba(37,99,235,0.35); }

@media (max-width: 768px) {
    .form-body { padding: 20px 20px; }
    .form-grid { grid-template-columns: 1fr; gap: 18px; }
}
</style>

<div class="form-card">
  <div class="form-header">
    <h2>Edit Leave Configuration</h2>
    <p>Update leave settings carefully</p>
  </div>
  <div class="form-body">
    <form action="<?=$base_url?>/leaveconfiguration/update" method="post">
      <input type="hidden" name="id" value="<?= $leaveconfiguration->id ?>">
      <div class="form-grid">

        <!-- Leave Type -->
        <div class="form-group">
          <input type="text" name="leave_type" id="leave_type" placeholder=" " value="<?= $leaveconfiguration->leave_type ?>" required>
          <label for="leave_type">Leave Type</label>
        </div>

        <!-- Total Days -->
        <div class="form-group">
          <input type="number" name="total_days" id="total_days" placeholder=" " value="<?= $leaveconfiguration->total_days ?>" required>
          <label for="total_days">Total Days (Per Year)</label>
        </div>

        <!-- Carry Forward -->
        <div class="form-group">
          <select name="carry_forward" id="carry_forward" required>
            <option value="1" <?= ($leaveconfiguration->carry_forward==1)?'selected':'' ?>>Yes</option>
            <option value="0" <?= ($leaveconfiguration->carry_forward==0)?'selected':'' ?>>No</option>
          </select>
          <label for="carry_forward">Carry Forward</label>
        </div>

        <!-- Description -->
        <div class="form-group">
          <textarea name="description" id="description" placeholder=" " rows="3"><?= $leaveconfiguration->description ?></textarea>
          <label for="description">Description</label>
        </div>

        <!-- Status -->
        <div class="form-group">
          <select name="status" id="status" required>
            <option value="Active" <?= ($leaveconfiguration->status=='Active')?'selected':'' ?>>Active</option>
            <option value="Inactive" <?= ($leaveconfiguration->status=='Inactive')?'selected':'' ?>>Inactive</option>
          </select>
          <label for="status">Status</label>
        </div>

        <!-- Submit Button -->
        <button type="submit" name="update" value="update" class="btn-submit">Update Leave Configuration</button>

      </div>
    </form>
  </div>
</div>

<?php
echo Page::context_close();
echo Page::body_close();
?>
