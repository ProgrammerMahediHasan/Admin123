<?php
echo Page::title(["title" => "Daily Attendance - IN"]);
echo Page::body_open();
echo Html::link([
    "class" => "btn btn-success mb-3",
    "route"  => "dailyattendance",
    "text"   => "← Back to Attendance List"
]);
echo Page::context_open();

global $db, $tx;

// Attendance date (default today)
$att_date = isset($_POST['att_date']) ? $_POST['att_date'] : date('Y-m-d');

// Fetch all employees
$employees = $db->query("SELECT id, name FROM {$tx}employees ORDER BY name ASC");

// Check if selected date is Friday
$weekday = date('D', strtotime($att_date));
$isFriday = ($weekday == 'Fri');
?>

<style>
.attendance-table {
    table-layout: fixed;
    width: 100%;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}
.attendance-table th,
.attendance-table td {
    vertical-align: middle;
    text-align: center;
    padding: 8px;
}
.attendance-table th {
    background-color: #0d6efd;
    color: white;
    font-weight: 600;
}
.attendance-table input[type="checkbox"] {
    width: 20px;
    height: 20px;
    cursor: pointer;
}
.attendance-table input[type="time"] {
    width: 100px;
}
.weekend {
    background: #f0f0f0;
    color: #555;
    font-weight: bold;
}
.form-section {
    background-color: #f8f9fa;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.1);
}
</style>

<div class="form-section">
    <h3 class="text-center mb-4">Employee Attendance (IN)</h3>

    <form action="<?= $base_url ?>/dailyattendance/save" method="post">
        <div class="row mb-4 justify-content-center">
            <div class="col-md-3">
                <label for="att_date" class="form-label fw-bold">Attendance Date:</label>
                <input 
                    type="date" 
                    class="form-control border-primary shadow-sm rounded-3 fw-semibold text-center" 
                    name="att_date" 
                    id="att_date" 
                    value="<?= $att_date ?>" 
                    required
                >
            </div>
        </div>

        <table class="table table-bordered table-striped table-hover attendance-table">
            <thead>
                <tr>
                    <th style="width:10%">SL</th>
                    <th style="width:50%">Employee Name</th>
                    <th style="width:20%">Present</th>
                    <th style="width:20%">Punch IN Time</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $sl = 1;
                while ($emp = $employees->fetch_object()):
                ?>
                    <tr>
                        <td><?= $sl++; ?></td>
                        <td>
                            <?= htmlspecialchars($emp->name); ?>
                            <input type="hidden" name="attendance[<?= $emp->id ?>][id]" value="<?= $emp->id ?>">
                        </td>

                        <?php if($isFriday): ?>
                            <td colspan="2"><span class="weekend">Weekend</span></td>
                        <?php else: ?>
                            <td>
                                <input type="checkbox" class="att-checkbox" name="attendance[<?= $emp->id ?>][p]" value="1">
                            </td>
                            <td>
                                <!-- Time input খালি রাখলাম, ব্যবহারকারী টাইম select করবে -->
                                <input type="time" name="attendance[<?= $emp->id ?>][time]" class="form-control punch-time" value="">
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <div class="text-center mt-4">
            <button type="submit" class="btn btn-primary px-5 py-2 shadow-sm">Save Attendance</button>
        </div>
    </form>
</div>

<?php echo Page::context_close(); ?>
