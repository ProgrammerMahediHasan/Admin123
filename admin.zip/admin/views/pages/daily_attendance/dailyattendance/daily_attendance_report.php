<?php
global $db,$tx;

// Date filter
$report_date = isset($_GET['date']) ? $_GET['date'] : date("Y-m-d");

// Export CSV if requested
if(isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="attendance_report_'. $report_date .'.csv"');

    $output = fopen('php://output', 'w');
    fputcsv($output, ['Emp ID','Employee Name','Attendance Date','In Time','Out Time','Total Work Minutes','Status','Late Minutes','Overtime Minutes']);

    $result = $db->query("
        SELECT e.id AS emp_id, e.name AS emp_name, 
               d.att_date, d.in_time, d.out_time, 
               d.total_work_minutes, d.status, d.late_minutes, d.overtime_minutes
        FROM {$tx}employees e
        LEFT JOIN {$tx}daily_attendance d 
               ON e.id = d.emp_id AND d.att_date = '$report_date'
        ORDER BY e.name ASC
    ");

    while($row = $result->fetch_object()){
        fputcsv($output, [
            $row->emp_id,
            $row->emp_name,
            $row->att_date ?? '-',
            $row->in_time ?? '-',
            $row->out_time ?? '-',
            $row->total_work_minutes ?? '-',
            $row->status ?? 'Absent',
            $row->late_minutes ?? '-',
            $row->overtime_minutes ?? '-'
        ]);
    }
    fclose($output);
    exit;
}





// Normal HTML report (view)
$result = $db->query("
    SELECT e.id AS emp_id, e.name AS emp_name, 
           d.att_date, d.in_time, d.out_time, 
           d.total_work_minutes, d.status, d.late_minutes, d.overtime_minutes
    FROM {$tx}employees e
    LEFT JOIN {$tx}daily_attendance d 
           ON e.id = d.emp_id AND d.att_date = '$report_date'
    ORDER BY e.name ASC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Employee Daily Attendance Report</title>
<style>
    body { font-family: Arial; background: #f5f7fa; padding: 20px; }
    h1 { text-align: center; color: #0d6efd; }
    table { border-collapse: collapse; width:100%; background:#fff; box-shadow:0 4px 15px rgba(0,0,0,0.1);}
    th, td { border:1px solid #ddd; padding:10px; text-align:center; }
    th { background: linear-gradient(135deg,#0d6efd,#004bba); color:#fff;}
    tr:nth-child(even){background-color:#f2f2f2;}
    tr:hover{background-color:#eef5ff;transition:0.3s;}
    .filter { text-align:center; margin-bottom:20px; }
    .filter input, .filter button, .filter a { padding:5px 10px; border-radius:5px; border:1px solid #ccc; text-decoration:none; margin-left:5px;}
    .filter button { background:#0d6efd; color:#fff; border:none; cursor:pointer; }
    .filter button:hover, .filter a:hover { background:#004bba; color:#fff; }
</style>
</head>
<body>

<h1>Employee Daily Attendance - <?= date("d-M-Y", strtotime($report_date)) ?></h1>

<div class="filter">
    <form method="get" style="display:inline-block;">
        <label for="date">Select Date: </label>
        <input type="date" name="date" value="<?= $report_date ?>">
        <button type="submit">Search</button>
    </form>
    <!-- <a href="?date=<?= $report_date ?>&export=csv">Export to CSV</a> -->
</div>

<table>
    <tr>
        <th>Emp ID</th>
        <th>Employee Name</th>
        <th>Attendance Date</th>
        <th>In Time</th>
        <th>Out Time</th>
        <th>Total Work Minutes</th>
        <th>Status</th>
        <th>Late Minutes</th>
        <th>Overtime Minutes</th>
    </tr>
    <?php while($row=$result->fetch_object()): ?>
    <tr>
        <td><?= $row->emp_id ?></td>
        <td><?= $row->emp_name ?></td>
        <td><?= $row->att_date ? date("d-M-Y", strtotime($row->att_date)) : "-" ?></td>
        <td><?= $row->in_time ?? "-" ?></td>
        <td><?= $row->out_time ?? "-" ?></td>
        <td><?= $row->total_work_minutes ?? "-" ?></td>
        <td><?= $row->status ?? "Absent" ?></td>
        <td><?= $row->late_minutes ?? "-" ?></td>
        <td><?= $row->overtime_minutes ?? "-" ?></td>
    </tr>
    <?php endwhile; ?>
</table>

</body>
</html>
